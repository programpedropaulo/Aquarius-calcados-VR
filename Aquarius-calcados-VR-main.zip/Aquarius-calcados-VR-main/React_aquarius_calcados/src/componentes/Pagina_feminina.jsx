function Pagina_feminina(props) {
  return (
    <div>
      <h1>{props.titulo}</h1>
      {/* conteúdo da página feminina aqui */}
    </div>
  );
}

export default Pagina_feminina;

