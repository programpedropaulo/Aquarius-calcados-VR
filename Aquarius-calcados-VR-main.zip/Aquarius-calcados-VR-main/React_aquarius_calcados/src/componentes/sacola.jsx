function Sacola() {
  return (
    <div>
      <h2>Minha sacola</h2>
    </div>
  );
}
export default Sacola;
