function Login(props) {
  return (
    <div>
      <h1>{props.titulo}</h1>
      {/* conteúdo da página Login aqui */}
    </div>
  );
}

export default Login;
