function Pagina_promocoes(props) {
  return (
    <div>
      <h1>{props.titulo}</h1>
      {/* conteúdo da página promocoes aqui */}
    </div>
  );
}

export default Pagina_promocoes;
