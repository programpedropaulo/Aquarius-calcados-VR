function Busca() {
  return (
    <div>
      <h2>Minha busca</h2>
    </div>
  );
}
export default Busca;
