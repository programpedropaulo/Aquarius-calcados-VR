function Administrador(props) {
  return (
    <div>
      <h1>{props.titulo}</h1>
      {/* conteúdo da página administrador aqui */}
    </div>
  );
}

export default Administrador;
