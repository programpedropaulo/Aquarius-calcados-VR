function Pagina_novidades(props) {
  return (
    <div>
      <h1>{props.titulo}</h1>
      {/* conteúdo da página novidades aqui */}
    </div>
  );
}

export default Pagina_novidades;
