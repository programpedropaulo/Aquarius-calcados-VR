function Perfil() {
  return (
    <div>
      <h2>Meu perfil</h2>
    </div>
  );
}
export default Perfil;
