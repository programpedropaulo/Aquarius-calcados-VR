function Pagina_masculina(props) {
  return (
    <div>
      <h1>{props.titulo}</h1>
      {/* conteúdo da página masculina aqui */}
    </div>
  );
}

export default Pagina_masculina;
