function Chat_com_vendedor() {
  return (
    <div>
      <h2>Minha sacola</h2>
    </div>
  );
}
export default Chat_com_vendedor;
